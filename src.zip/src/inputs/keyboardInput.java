package inputs;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class keyboardInput implements KeyListener {

    public boolean w = false;
    public boolean a = false;
    public boolean s = false;
    public boolean d = false;

    @Override
    public void keyTyped(KeyEvent e) {
        // Metodo non utilizzato per la pressione dei tasti
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) {
            this.w = true;
        }else if(e.getKeyCode() == KeyEvent.VK_A){
            this.a = true;
        }else if(e.getKeyCode() == KeyEvent.VK_S){
            this.s = true;
        }else if(e.getKeyCode() == KeyEvent.VK_D){
            this.d = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) {
            this.w = false;
        }else if(e.getKeyCode() == KeyEvent.VK_A){
            this.a = false;
        }else if(e.getKeyCode() == KeyEvent.VK_S){
            this.s = false;
        }else if(e.getKeyCode() == KeyEvent.VK_D){
            this.d = false;
        }
    }

    public static void main(String[] args) {
        // Aggiungi il KeyListener al componente appropriato
        // Esempio: frame.addKeyListener(new MyKeyListener());
    }
}