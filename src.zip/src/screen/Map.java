package screen;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

// input

import inputs.keyboardInput;

public class Map extends JFrame implements Runnable {
    BufferedImage img;
    keyboardInput k = new keyboardInput();
    Thread gameThread;
    final int FPS = 60;
    JPanel p = new JPanel();

    // coord

    int x = 100;
    int y = 100;

    public Map() {

        this.add(p);
        this.addKeyListener(k);
        this.setSize(500, 500);
        this.setVisible(true);

        try{
            img = ImageIO.read(getClass().getResourceAsStream("/playerSingle.png"));
        }catch(IOException e){
            System.out.println("errore: " + e);
        }
        startGameThread();

    }

    public void startGameThread(){

        gameThread = new Thread(this);
        gameThread.start();

    }

    @Override
    public void run(){

        double drawInterval = 1000000000 / FPS;
        double nextDrawTime = System.nanoTime() + drawInterval;

        while (gameThread != null) {
            
            update();

            repaint();
            
            try{

                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;

                if(remainingTime < 0){
                    remainingTime = 0;
                }
                
                Thread.sleep((long) remainingTime);

                nextDrawTime += drawInterval;


            }catch(Exception e){
                
                System.out.println("Erorre: " + e);

            }

        }

    }

    public void update(){

        // controlla che non esca dai bordi

        if(k.w){
            y--;
        }else if(k.a){
            x--;
        }else if(k.s){
            y++;
        }else if(k.d){
            x++;
        }


    }


    public void paintComponent(Graphics g){

        // sistemare

        Graphics2D g2 = (Graphics2D)g;

        g2.setColor(Color.white);
        g2.fillRect(x, y, 31, 31);
        
    }



}